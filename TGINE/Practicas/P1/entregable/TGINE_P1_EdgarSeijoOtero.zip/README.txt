Para ejecutar el script:

python TGINE_S1.py [-s <subreddit>] [-t <content(hot, new)>] [-n <posts number] [-f <filename>]

Si no se especifica alguno de los parámetros, tomarán valores por defecto y la ejecución de:

python TGINE_S1.py

se correspondería a ejecutar:

python TGINE_S1.py -s personalfinance -t hot -n 100 -f redditextractor_data.xml